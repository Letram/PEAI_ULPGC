import Foundation

protocol DBModel {}
